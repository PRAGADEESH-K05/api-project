package com.rest.springapp.service;

public class ReviewService {
    
}
