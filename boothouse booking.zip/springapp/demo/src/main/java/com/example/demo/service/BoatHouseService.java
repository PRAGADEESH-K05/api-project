package com.example.demo.service;

import com.example.demo.model.BoatHouse;
import com.example.demo.repository.BoatHouseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class BoatHouseService {

    private final BoatHouseRepository repository;

    @Autowired
    public BoatHouseService(BoatHouseRepository repository) {
        this.repository = repository;
    }

    public List<BoatHouse> getAllBoatHouses() {
        return repository.findAll();
    }
}