package com.example.demo.aspect;

public class LoggingAspect {
    
}
