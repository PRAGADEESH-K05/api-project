package com.example.demo.service;

import com.example.demo.model.Owner;
import com.example.demo.repository.OwnerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OwnerService {

    @Autowired
    private OwnerRepository OwnerRepository;

    public List<Owner> getAllOwners() {
        return OwnerRepository.findAll();
    }

    public Optional<Owner> getOwnerById(Long id) {
        return OwnerRepository.findById(id);
    }

    public Owner createOwner(Owner owner) {
        return OwnerRepository.save(owner);
    }

    public void deleteOwner(Long id) {
        OwnerRepository.deleteById(id);
    }
}

